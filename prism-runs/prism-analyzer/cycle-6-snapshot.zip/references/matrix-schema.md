# Машиночитаемая Матрица отказов

`cycle-<N>-matrix.json` — та же матрица, что и `cycle-<N>-matrix.md`, для исправителя-ИИ и для инструментов. Содержание обоих файлов должно совпадать: JSON не добавляет ни оценок, ни выводов. Поле, которого нет в матрице, — `null`, а не выдуманное значение. Простое изложение `cycle-<N>-summary-human.md` (`references/summary-human.md`) — та же матрица для человека: с ней не расходится и ничего к ней не добавляет.

```json
{
  "prism_version": "0.10.0",
  "previous_prism_version": null,
  "system": "oncall-alerting",
  "cycle": 1,
  "causa_finalis": {
    "result": "…", "beneficiary": "…", "criterion": "…", "horizon": "…",
    "assumptions": ["горизонт принят как календарный год"],
    "source": "declared | arbiter | inferred",
    "declared_goal_mismatch": null
  },
  "snapshot": {"kind": "git | archive | copy | none", "ref": "adbca5d | sha256:… | path"},
  "scout": {"mode": "full | light", "files_read": 12, "discrepancies": 3},
  "isolation": "subagents | single-context | manual",
  "context_composition": {"status": "established | not-established", "basis": "…",
                          "environment": "established | not-established",
                          "content": "clean | materials-describe-probes | description-points-to-original",
                          "placement": "separate-trees | violated: …", "trace": "none | contact: …"},
  "roles": "dispatcher-not-fixer | dispatcher-is-fixer",
  "completeness": {
    "status": "measured | not-measured-independently | not-measured",
    "reason": null,
    "found": 2, "known": 3,
    "internal": {"seed": [1, 2], "fixer": [0, 1]},
    "probe": [{"vector": "3.1", "kind": "seed | counter-seed | health-check", "case": "p1 | 3.1-a",
               "result": "found | missed | other-breach | not-received | distinguished | not-distinguished",
               "blind": true, "blind_reason": null, "context": "established | not-established", "counted": true}],
    "known_breaches": [{"source": "reality | review | fixer | arbiter", "independent": true, "text": "…", "zone": "1.2",
                        "found_as": "B1-1.2-01", "sealed": true}]
  },
  "goal_control": null,
  "tool_transition": null,
  "center_of_gravity": "…",
  "relief_map": [
    {"vector": "3.1", "E": 3, "S": 3, "L": 3, "modifiers": [], "P": 27,
     "decision": "activated | not-activated | recheck | manual", "signals": ["«цитата»"]}
  ],
  "breaches": [
    {
      "id": "B1-3.1-01",
      "vector": "3.1",
      "mode": "full | recheck | micro",
      "recheck_verdict": null,
      "law": "3.1.6", "amplifier": "3.1.7",
      "essence": "…",
      "localization": "path:line | элемент",
      "basis": "система предполагает, что … | null",
      "evidence": [{"kind": "fact | fact-absence | fact-scout | assumption", "text": "…", "source": "path:line | description | Р2"}],
      "type": "fact | assumption",
      "mechanics": "…",
      "closure_condition": {"state": "…", "check": "…"},
      "probability_pct": [30, 60], "probability_basis": "…",
      "harm_pct": [60, 100], "harm_basis": "…",
      "index": {"I": 2, "T": 2, "D": 2, "value": 8, "I_why": "…", "D_why": "…"},
      "other_candidates": ["3.1.1", "3.1.9"],
      "signals": [{"to": "2.1", "text": "…"}],
      "border_control": []
    }
  ],
  "protected": [{"vector": "2.1", "mode": "full | recheck", "recheck_id": null, "recheck_verdict": null,
                 "checked": [{"law": "2.1.3", "why_not_fatal": "…"}],
                 "confirmation": "seed-found | unconfirmed | refuted", "confirmation_basis": "…",
                 "verdict_confirmation": null, "verdict_confirmation_basis": null}],
  "micro": [{"vector": "1.1", "checked": [{"law": "1.1.4", "why_not_fatal": "…"}],
             "law": "1.1.3", "where": "…", "losses_pct": [5, 10], "losses_basis": "…",
             "confirmation": "seed-found | unconfirmed | refuted", "confirmation_basis": "…"}],
  "open_from_previous": [{"id": "B1-2.2-01", "status": "not-fixed | carried"}],
  "not_activated": [{"vector": "1.1", "P": 12, "reason": "below-cutoff | no-data | open-breach | excluded"}],
  "contradictions": [],
  "duplicates": [],
  "signals_next_cycle": [{"to": "3.2", "from": "1.2 | completeness", "text": "…"}],
  "persistence_warning": true
}
```

Правила:
- `breaches` — в порядке блоков матрицы (шаг 7 SKILL.md); номер `id` постоянный между циклами. Брешь, найденная в режиме МИКРО, — здесь, с `"mode": "micro"`.
- `probability_pct` / `harm_pct` — `null`, если в матрице «не оценивается»; тогда в `*_basis` — чего не хватает.
- `basis` — `null`, если «не выявлено».
- `completeness` — в каждом цикле (`references/completeness.md`). Известных брешей нет — `"status": "not-measured"`, `found` и `known` — `null`, в `reason` — почему. В `found` и `known` входят только пробы `kind: "seed"` (`counted: true`); `counter-seed` и `health-check` — `counted: false`; проба с результатом `not-received` тоже не входит. `blind: false` — проба не слепая, причина в `blind_reason`: `"mode-b"`, `"materials-describe-probes"` (в том числе самоанализ Prism), `"description-points-to-original"`, `"placement"`, `"trace"`; `context: "not-established"` — состав контекста не установлен, невыполненная часть — в `context_composition`; `sealed: false` — сведения Арбитра переданы открыто до съёмки.
- Контур проверки (`references/completeness.md`, раздел 1). `found` и `known` — только независимые источники: сведения вне контура (`independent: true`) и пробы посева, сделанного Арбитром или другим человеком. Посев Сеятеля и находки исправителя — в `internal` как `[найдено, всего]`, в `found` и `known` не входят. Независимых источников нет — `"status": "not-measured-independently"`, `found` и `known` — `null`, `internal` заполнен. Известных брешей нет ни в одном источнике — `"not-measured"`. `independent` у известной бреши — кто её установил: `false` для `source: "fixer"`, для всего, что сделал Prism любой версии, и когда установивший не назван.
- `tool_transition` — только при самоанализе Prism (SKILL.md, «Переход версии в роль инструмента»): `{"tool": {"version": "…", "commit": "…", "accepted_by": "путь к файлу приёмки" | null}, "acceptance": {"file": "…", "accepted": x, "debt": y, "not_accepted": ["B…"]} | null, "basis": "acceptance | none", "reason": "…" | null}`; матрица самоанализа основанием не служит, поэтому `basis` берётся только из приёмки; у остальных систем — `null`.
- `confirmation` — у каждого элемента `protected` и `micro`: подтверждение защищённости посевом; в `confirmation_basis` — результат пробы посева зоны, состав контекста или пропущенная известная брешь.
- Перепроверка с вердиктом ЗАКРЫТА или СНЯТА — элемент `protected` с `"mode": "recheck"`, `recheck_id` (номер бреши) и `recheck_verdict` (`"closed" | "dismissed"`); `verdict_confirmation` — `"counter-seed-distinguished" | "unconfirmed" | "refuted"`, в `verdict_confirmation_basis` — результат пробы контрпосева или известная брешь. У остальных элементов эти поля — `null`. Подтверждён узел, только если подтверждены обе части.
- `micro` — только с цикла 2; в примере показан формат элемента.
- `goal_control` (цикл N>1): `{"precision": [a, b], "confirmed_closures": {"independent": [c, d] | null, "internal": [c2, d]}, "unconfirmed_closures": u, "wrong_closures": {"independent": [{"id": "B1-3.1-01", "cycle": K, "source": "arbiter", "found_as": "текст", "recount": [[c, d], [c2, d]]}] | null, "internal": [{"id": "…", "cycle": K, "source": "prism | fixer", "found_as": "B3-3.1-01 | текст"}]}, "misses": {"independent": e | null, "fixer": e2, "found_later": f}}`. `independent` — только по независимым источникам; `null` на его месте — «не измерены независимо»; `internal`, `fixer` и `found_later` — внутренние, «внутренний — не измеряет»; `null` на месте показателя — «не определена» / «не измерены», а не лучшее значение; `found_later` — нижняя граница.
- `signals_next_cycle` — `"from": "completeness"` для известной бреши, которую прогон пропустил.
- Советов и исправлений в JSON нет — как и в матрице.
